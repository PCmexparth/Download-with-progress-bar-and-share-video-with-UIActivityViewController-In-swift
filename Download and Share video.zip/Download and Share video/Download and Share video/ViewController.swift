//
//  ViewController.swift
//  Download and Share video
//
//  Created by Parth Changela on 23/08/18.
//  Copyright © 2018 PCmex. All rights reserved.
//

import UIKit

class ViewController: UIViewController,URLSessionDownloadDelegate {

    @IBOutlet weak var btnShareVideo: UIButton!

    var progress: Float = 0.0
    var task: URLSessionTask!

    var percentageWritten:Float = 0.0
    var taskTotalBytesWritten = 0
    var taskTotalBytesExpectedToWrite = 0

    lazy var session : URLSession = {
        let config = URLSessionConfiguration.default
        // config.allowsCellularAccess = false
        let session = URLSession(configuration: config, delegate: self, delegateQueue: OperationQueue.main)
        return session
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnShareVideoTapped(_ sender: Any) {

        var hud =  MBProgressHUD.showAdded(to: self.view, animated: true)
        // Set the bar determinate mode to show task progress.
        progress = 0.0
        hud?.mode = MBProgressHUDMode.determinateHorizontalBar
        hud?.isUserInteractionEnabled = true;
        hud?.labelText = NSLocalizedString("Downloading...", comment: "HUD loading title")
        DispatchQueue.global(qos: .default).async(execute: {() -> Void in
            // Do something useful in the background and update the HUD periodically.
            self.doSomeWorkWithProgress()
            DispatchQueue.main.async(execute: {() -> Void in
                //hud?.hide(true)
                hud?.labelText = NSLocalizedString("Just Wait...", comment: "HUD loading title")
            })
        })


        let videoPath = "http://159.65.154.78:8002/storage/whatsapp-status/video/2018/07/26/Zd1XMyCZIpd3XHREyWFOou9ig98IzcJKxEYR8fzd.mp4"
        print(videoPath)
        //let urlData = NSData(contentsOf: NSURL(string:"\(getDataArray["video_url"] as! String)")! as URL)
        let s = videoPath
        let url = NSURL(string:s)!
        let req = NSMutableURLRequest(url:url as URL)
        let config = URLSessionConfiguration.default
        let task = self.session.downloadTask(with: req as URLRequest)
        self.task = task
        task.resume()

    }

    //MARK:- share video
    func doSomeWorkWithProgress() {
        // This just increases the progress indicator in a loop.
        while progress < 1.0 {
            DispatchQueue.main.async(execute: {() -> Void in
                // Instead we could have also passed a reference to the HUD
                // to the HUD to myProgressTask as a method parameter.
                print(self.progress)
                MBProgressHUD(for: self.view).progress = self.progress
            })
            usleep(50000)
        }
    }

    //MARK:- URL Session delegat
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        print("downloaded \(100*totalBytesWritten/totalBytesExpectedToWrite)")
        taskTotalBytesWritten = Int(totalBytesWritten)
        taskTotalBytesExpectedToWrite = Int(totalBytesExpectedToWrite)
        percentageWritten = Float(taskTotalBytesWritten) / Float(taskTotalBytesExpectedToWrite)
        print(percentageWritten)
        //  let x = Double(percentageWritten).rounded(toPlaces: 2)
        let x = String(format:"%.2f", percentageWritten)
        print(x)
        self.progress = Float(x)!
        print(progress)

    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didResumeAtOffset fileOffset: Int64, expectedTotalBytes: Int64) {
        // unused in this example
    }



    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        print("completed: error: \(error)")
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        print("Finished downloading!")
        let fileManager = FileManager()
        // this can be a class variable
        let directoryURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        print(directoryURL)
        let docDirectoryURL = NSURL(fileURLWithPath: "\(directoryURL)")
        print(docDirectoryURL)
        // Get the original file name from the original request.
        //print(lastPathComponent)
        let destinationFilename = downloadTask.originalRequest?.url?.lastPathComponent
        print(destinationFilename!)
        // append that to your base directory
        let destinationURL =  docDirectoryURL.appendingPathComponent("\(destinationFilename!)")
        print(destinationURL!)
        /* check if the file exists, if so remove it. */
        if let path = destinationURL?.path {
            if fileManager.fileExists(atPath: path) {
                do {
                    try fileManager.removeItem(at: destinationURL!)

                } catch let error as NSError {
                    print(error.debugDescription)
                }

            }
        }

        do
        {
            try fileManager.copyItem(at: location, to: destinationURL!)
        }
        catch {
            print("Error while copy file")

        }
        DispatchQueue.main.async(execute: {() -> Void in
            MBProgressHUD.hide(for: self.view, animated: true)
        })
        // let videoLink = NSURL(fileURLWithPath: filePath)
        let objectsToShare = [destinationURL!] //comment!, imageData!, myWebsite!]
        let activityVC = UIActivityViewController(activityItems: objectsToShare , applicationActivities: nil)
        activityVC.setValue("Video", forKey: "subject")
        //New Excluded Activities Code
        if #available(iOS 9.0, *) {
            activityVC.excludedActivityTypes = [UIActivityType.airDrop, UIActivityType.addToReadingList, UIActivityType.assignToContact, UIActivityType.copyToPasteboard, UIActivityType.mail, UIActivityType.message, UIActivityType.openInIBooks, UIActivityType.postToTencentWeibo, UIActivityType.postToVimeo, UIActivityType.postToWeibo, UIActivityType.print]
        } else {
            // Fallback on earlier versions
            activityVC.excludedActivityTypes = [UIActivityType.airDrop, UIActivityType.addToReadingList, UIActivityType.assignToContact, UIActivityType.copyToPasteboard, UIActivityType.mail, UIActivityType.message, UIActivityType.postToTencentWeibo, UIActivityType.postToVimeo, UIActivityType.postToWeibo, UIActivityType.print ]
        }
        if let popoverController = activityVC.popoverPresentationController {
            popoverController.sourceView = self.btnShareVideo
            popoverController.sourceRect = self.btnShareVideo.bounds

        }
        self.present(activityVC, animated: true, completion: nil)
    }

}

